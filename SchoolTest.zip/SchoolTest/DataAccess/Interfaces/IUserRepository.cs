﻿using DataAccess.Models;

namespace DataAccess.Interfaces
{
    public interface IUserRepository : IRepositoryBase<Пользователи>
    {
    }
}
