﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class ПравильныеОтветы
{
    public long IdПрОтвета { get; set; }

    public long IdЗадания { get; set; }

    public long? IdОтвета { get; set; }

    public virtual Задания IdЗаданияNavigation { get; set; } = null!;

    public virtual Ответы? IdОтветаNavigation { get; set; }
}
