﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Models;

public partial class SchoolTestContext : DbContext
{
    public SchoolTestContext()
    {
    }

    public SchoolTestContext(DbContextOptions<SchoolTestContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Задания> Заданияs { get; set; }

    public virtual DbSet<Ответы> Ответыs { get; set; }

    public virtual DbSet<ОтветыПользователя> ОтветыПользователяs { get; set; }

    public virtual DbSet<Пользователи> Пользователиs { get; set; }

    public virtual DbSet<ПравильныеОтветы> ПравильныеОтветыs { get; set; }

    public virtual DbSet<ПрохождениеТеста> ПрохождениеТестаs { get; set; }

    public virtual DbSet<Роли> Ролиs { get; set; }

    public virtual DbSet<Тесты> Тестыs { get; set; }

    public virtual DbSet<ТипыЗаданий> ТипыЗаданийs { get; set; }

    public virtual DbSet<Файлы> Файлыs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=localhost;Database=SchoolTest;User Id=sa;Password=12345;Encrypt=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Задания>(entity =>
        {
            entity.HasKey(e => e.IdЗадания).HasName("PK__Задания__E0BA2DB421073674");

            entity.ToTable("Задания");

            entity.Property(e => e.IdЗадания).HasColumnName("id задания");
            entity.Property(e => e.IdТеста).HasColumnName("id теста");
            entity.Property(e => e.IdТипаЗадания).HasColumnName("id типа задания");
            entity.Property(e => e.ТекстВопроса)
                .HasMaxLength(255)
                .HasColumnName("текст вопроса");

            entity.HasOne(d => d.IdТестаNavigation).WithMany(p => p.Заданияs)
                .HasForeignKey(d => d.IdТеста)
                .HasConstraintName("FK__Задания__id тест__300424B4");

            entity.HasOne(d => d.IdТипаЗаданияNavigation).WithMany(p => p.Заданияs)
                .HasForeignKey(d => d.IdТипаЗадания)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Задания__id типа__30F848ED");
        });

        modelBuilder.Entity<Ответы>(entity =>
        {
            entity.HasKey(e => e.IdОтвета).HasName("PK__Ответы__B4BC00FF4A16E93F");

            entity.ToTable("Ответы");

            entity.Property(e => e.IdОтвета).HasColumnName("id ответа");
            entity.Property(e => e.IdЗадания).HasColumnName("id задания");
            entity.Property(e => e.Текст)
                .HasMaxLength(255)
                .HasColumnName("текст");

            entity.HasOne(d => d.IdЗаданияNavigation).WithMany(p => p.Ответыs)
                .HasForeignKey(d => d.IdЗадания)
                .HasConstraintName("FK__Ответы__id задан__36B12243");
        });

        modelBuilder.Entity<ОтветыПользователя>(entity =>
        {
            entity.HasKey(e => e.IdОтветаПользователя).HasName("PK__Ответы п__C60A26CBA0F97BBF");

            entity.ToTable("Ответы пользователя");

            entity.Property(e => e.IdОтветаПользователя).HasColumnName("id ответа пользователя");
            entity.Property(e => e.IdЗадания).HasColumnName("id задания");
            entity.Property(e => e.IdОтвета).HasColumnName("id ответа");
            entity.Property(e => e.IdПрохождения).HasColumnName("id прохождения");
            entity.Property(e => e.Текст)
                .HasMaxLength(255)
                .HasColumnName("текст");

            entity.HasOne(d => d.IdЗаданияNavigation).WithMany(p => p.ОтветыПользователяs)
                .HasForeignKey(d => d.IdЗадания)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Ответы по__id за__4222D4EF");

            entity.HasOne(d => d.IdОтветаNavigation).WithMany(p => p.ОтветыПользователяs)
                .HasForeignKey(d => d.IdОтвета)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Ответы по__id от__4316F928");

            entity.HasOne(d => d.IdПрохожденияNavigation).WithMany(p => p.ОтветыПользователяs)
                .HasForeignKey(d => d.IdПрохождения)
                .HasConstraintName("FK__Ответы по__id пр__412EB0B6");
        });

        modelBuilder.Entity<Пользователи>(entity =>
        {
            entity.HasKey(e => e.IdПользователя).HasName("PK__Пользова__BCE4E31219844731");

            entity.ToTable("Пользователи");

            entity.HasIndex(e => e.Почта, "UQ__Пользова__E2BF35292F4739F3").IsUnique();

            entity.Property(e => e.IdПользователя).HasColumnName("id пользователя");
            entity.Property(e => e.IdРоли).HasColumnName("id роли");
            entity.Property(e => e.Имя).HasMaxLength(100);
            entity.Property(e => e.Отчество).HasMaxLength(100);
            entity.Property(e => e.Пароль).HasMaxLength(50);
            entity.Property(e => e.Почта).HasMaxLength(100);
            entity.Property(e => e.Фамилия).HasMaxLength(100);

            entity.HasOne(d => d.IdРолиNavigation).WithMany(p => p.Пользователиs)
                .HasForeignKey(d => d.IdРоли)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Пользоват__id ро__286302EC");
        });

        modelBuilder.Entity<ПравильныеОтветы>(entity =>
        {
            entity.HasKey(e => e.IdПрОтвета).HasName("PK__правильн__D77D594F2CCB848E");

            entity.ToTable("правильные ответы");

            entity.Property(e => e.IdПрОтвета).HasColumnName("id пр. ответа");
            entity.Property(e => e.IdЗадания).HasColumnName("id задания");
            entity.Property(e => e.IdОтвета).HasColumnName("id ответа");

            entity.HasOne(d => d.IdЗаданияNavigation).WithMany(p => p.ПравильныеОтветыs)
                .HasForeignKey(d => d.IdЗадания)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__правильны__id за__3D5E1FD2");

            entity.HasOne(d => d.IdОтветаNavigation).WithMany(p => p.ПравильныеОтветыs)
                .HasForeignKey(d => d.IdОтвета)
                .HasConstraintName("FK__правильны__id от__3E52440B");
        });

        modelBuilder.Entity<ПрохождениеТеста>(entity =>
        {
            entity.HasKey(e => e.IdПрохождения).HasName("PK__Прохожде__6B8C1C01257CDD44");

            entity.ToTable("Прохождение теста");

            entity.Property(e => e.IdПрохождения).HasColumnName("id прохождения");
            entity.Property(e => e.IdПользователь).HasColumnName("id пользователь");
            entity.Property(e => e.IdТест).HasColumnName("id тест");
            entity.Property(e => e.ВремяЗавершения)
                .HasColumnType("datetime")
                .HasColumnName("Время завершения");
            entity.Property(e => e.ВремяНачало)
                .HasColumnType("datetime")
                .HasColumnName("Время начало");

            entity.HasOne(d => d.IdПользовательNavigation).WithMany(p => p.ПрохождениеТестаs)
                .HasForeignKey(d => d.IdПользователь)
                .HasConstraintName("FK__Прохожден__id по__3A81B327");

            entity.HasOne(d => d.IdТестNavigation).WithMany(p => p.ПрохождениеТестаs)
                .HasForeignKey(d => d.IdТест)
                .HasConstraintName("FK__Прохожден__id те__398D8EEE");
        });

        modelBuilder.Entity<Роли>(entity =>
        {
            entity.HasKey(e => e.IdРоли).HasName("PK__Роли__E72CC0743EF23B36");

            entity.ToTable("Роли");

            entity.HasIndex(e => e.ИмяРоли, "UQ__Роли__58ED10062413AA4D").IsUnique();

            entity.Property(e => e.IdРоли).HasColumnName("id роли");
            entity.Property(e => e.ИмяРоли)
                .HasMaxLength(50)
                .HasColumnName("Имя роли");
        });

        modelBuilder.Entity<Тесты>(entity =>
        {
            entity.HasKey(e => e.IdТеста).HasName("PK__Тесты__8104BDF1C7757440");

            entity.ToTable("Тесты");

            entity.Property(e => e.IdТеста).HasColumnName("id теста");
            entity.Property(e => e.Название).HasMaxLength(200);
            entity.Property(e => e.Описание).HasMaxLength(500);
        });

        modelBuilder.Entity<ТипыЗаданий>(entity =>
        {
            entity.HasKey(e => e.IdТипЗадания).HasName("PK__Типы зад__D17CCFA051844B03");

            entity.ToTable("Типы заданий");

            entity.HasIndex(e => e.Название, "UQ__Типы зад__38DA8035459477C0").IsUnique();

            entity.Property(e => e.IdТипЗадания).HasColumnName("id тип задания");
            entity.Property(e => e.Название).HasMaxLength(50);
        });

        modelBuilder.Entity<Файлы>(entity =>
        {
            entity.HasKey(e => e.IdФайла).HasName("PK__Файлы__33AA69057B1B1F7B");

            entity.ToTable("Файлы");

            entity.Property(e => e.IdФайла).HasColumnName("id файла");
            entity.Property(e => e.IdЗадания).HasColumnName("id задания");
            entity.Property(e => e.ПутьФайла)
                .HasMaxLength(255)
                .HasColumnName("Путь файла");

            entity.HasOne(d => d.IdЗаданияNavigation).WithMany(p => p.Файлыs)
                .HasForeignKey(d => d.IdЗадания)
                .HasConstraintName("FK__Файлы__id задани__33D4B598");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
