﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class Пользователи
{
    public long IdПользователя { get; set; }

    public string Фамилия { get; set; } = null!;

    public string Имя { get; set; } = null!;

    public string Отчество { get; set; } = null!;

    public string Почта { get; set; } = null!;

    public string Пароль { get; set; } = null!;

    public long IdРоли { get; set; }

    public virtual Роли IdРолиNavigation { get; set; } = null!;

    public virtual ICollection<ПрохождениеТеста> ПрохождениеТестаs { get; set; } = new List<ПрохождениеТеста>();
}
