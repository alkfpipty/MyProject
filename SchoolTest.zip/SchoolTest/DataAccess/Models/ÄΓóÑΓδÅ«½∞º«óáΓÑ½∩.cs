﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class ОтветыПользователя
{
    public long IdОтветаПользователя { get; set; }

    public long IdПрохождения { get; set; }

    public long IdЗадания { get; set; }

    public long IdОтвета { get; set; }

    public string Текст { get; set; } = null!;

    public virtual Задания IdЗаданияNavigation { get; set; } = null!;

    public virtual Ответы IdОтветаNavigation { get; set; } = null!;

    public virtual ПрохождениеТеста IdПрохожденияNavigation { get; set; } = null!;
}
