﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class Тесты
{
    public long IdТеста { get; set; }

    public string Название { get; set; } = null!;

    public string Описание { get; set; } = null!;

    public virtual ICollection<Задания> Заданияs { get; set; } = new List<Задания>();

    public virtual ICollection<ПрохождениеТеста> ПрохождениеТестаs { get; set; } = new List<ПрохождениеТеста>();
}
