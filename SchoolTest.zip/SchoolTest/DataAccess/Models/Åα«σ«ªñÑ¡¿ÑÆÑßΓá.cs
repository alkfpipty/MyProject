﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class ПрохождениеТеста
{
    public long IdПрохождения { get; set; }

    public long IdТест { get; set; }

    public long IdПользователь { get; set; }

    public DateTime ВремяНачало { get; set; }

    public DateTime? ВремяЗавершения { get; set; }

    public int? Результат { get; set; }

    public virtual Пользователи IdПользовательNavigation { get; set; } = null!;

    public virtual Тесты IdТестNavigation { get; set; } = null!;

    public virtual ICollection<ОтветыПользователя> ОтветыПользователяs { get; set; } = new List<ОтветыПользователя>();
}
