﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class Роли
{
    public long IdРоли { get; set; }

    public string ИмяРоли { get; set; } = null!;

    public virtual ICollection<Пользователи> Пользователиs { get; set; } = new List<Пользователи>();
}
