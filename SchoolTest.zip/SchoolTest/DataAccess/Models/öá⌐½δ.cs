﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class Файлы
{
    public long IdФайла { get; set; }

    public long IdЗадания { get; set; }

    public string ПутьФайла { get; set; } = null!;

    public virtual Задания IdЗаданияNavigation { get; set; } = null!;
}
