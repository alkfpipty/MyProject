﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class Ответы
{
    public long IdОтвета { get; set; }

    public long IdЗадания { get; set; }

    public string Текст { get; set; } = null!;

    public virtual Задания IdЗаданияNavigation { get; set; } = null!;

    public virtual ICollection<ОтветыПользователя> ОтветыПользователяs { get; set; } = new List<ОтветыПользователя>();

    public virtual ICollection<ПравильныеОтветы> ПравильныеОтветыs { get; set; } = new List<ПравильныеОтветы>();
}
