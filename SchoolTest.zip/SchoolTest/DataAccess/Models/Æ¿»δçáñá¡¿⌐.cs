﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class ТипыЗаданий
{
    public long IdТипЗадания { get; set; }

    public string Название { get; set; } = null!;

    public virtual ICollection<Задания> Заданияs { get; set; } = new List<Задания>();
}
