﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class Задания
{
    public long IdЗадания { get; set; }

    public long IdТеста { get; set; }

    public long IdТипаЗадания { get; set; }

    public string ТекстВопроса { get; set; } = null!;

    public virtual Тесты IdТестаNavigation { get; set; } = null!;

    public virtual ТипыЗаданий IdТипаЗаданияNavigation { get; set; } = null!;

    public virtual ICollection<Ответы> Ответыs { get; set; } = new List<Ответы>();

    public virtual ICollection<ОтветыПользователя> ОтветыПользователяs { get; set; } = new List<ОтветыПользователя>();

    public virtual ICollection<ПравильныеОтветы> ПравильныеОтветыs { get; set; } = new List<ПравильныеОтветы>();

    public virtual ICollection<Файлы> Файлыs { get; set; } = new List<Файлы>();
}
