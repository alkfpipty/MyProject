﻿using DataAccess.Models;
using DataAccess.Interfaces;

namespace DataAccess.Repositories
{
    public class UserRepository : RepositoryBase<Пользователи>, IUserRepository
    {
        public UserRepository(SchoolTestContext repositoryContext) 
            : base(repositoryContext)
        {
        }
    }
}
